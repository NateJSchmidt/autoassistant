package com.natejschmidt.autoassistant.com.natejschmidt.autoassistant.models

abstract class ActionModel(open val index: Int)